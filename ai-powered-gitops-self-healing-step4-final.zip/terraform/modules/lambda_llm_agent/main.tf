variable "project_name" { type = string }
variable "role_arn" { type = string }







variable "aws_region" { type = string }
variable "cluster_name" { type = string }
variable "prometheus_query_url" { type = string }
data "archive_file" "zip" {
  type        = "zip"
  source_dir  = "${path.module}/src"
  output_path = "${path.module}/function.zip"
}

resource "aws_lambda_function" "this" {
  function_name = "${var.project_name}-lambda_llm_agent"
  role          = var.role_arn
  runtime       = "python3.11"
  handler       = "app.handler"
  filename      = data.archive_file.zip.output_path
  timeout       = 30

  environment {
    variables = {
      GITHUB_OWNER = var.github_owner
      GITHUB_REPO = var.github_repo
      GITHUB_APP_TOKEN_SECRET_ARN = var.github_token_secret_arn
      MODEL_PROVIDER = var.model_provider
      ALLOWED_ACTIONS_PATH = "gitops/policies/allowed-actions.yaml"
      AWS_REGION = var.aws_region
      CLUSTER_NAME = var.cluster_name
      PROMETHEUS_QUERY_URL = var.prometheus_query_url
    }
  }
}

output "lambda_arn"  { value = aws_lambda_function.this.arn }
output "lambda_name" { value = aws_lambda_function.this.function_name }
